from bs4 import BeautifulSoup
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
import mechanicalsoup as ms
import pandas as pd
import requests
import smtplib as smtp

def wsCnpjEmpresas (df):
    
    #Criando dicionários de campos que queremos do site
    campos = {
        "Id":"empresaVagas_ds",
        "CNPJ": "cnpj_ds",
        "Razão Social": "razaoSocial_ds",
        "Nome Fantasia" : "fantasia_ds",
        "Data Abertura": "dataAbertura_dt",
        "Natureza Jurídica": "naturezaJuridica_ds",
        "Tipo": "tipo_ds",
        "Situação": "situacao_ds",
        "Estado": "estado_ds",
        "Sobre": "sobre_ds"
    }
    
    
    #Criando dados fakes para inserir no dataset zerado
    empresas = [{
                "Empresa Exemplo Vagas",
                "CNPJ",
                "Dados"}]
    
    #Criando dataset com os dados fakes e com nome das colunas
    dfCnpj = pd.DataFrame(empresas, columns = [
                                               "nomeEmpresa_ds",
                                               "campo_ds",
                                               "valor_ds"
                                               ]
                          )
    #Contadores do dataset
    row = 0

    #Buscando os itens no site
    for ind in df.index:
        TimeExecucao(5000)
        
        #URL de conexão com o site para manipulação do browser
        empresaPrincipal = str(df['Empresa'][ind])
        url = "https://cnpj.biz/procura/" + str(df['Empresa'][ind])
        
        #Abrindo o browser e conectando com o site
        browser = ms.StatefulBrowser()
        browser.open(url)

        #Verificando se a conexão foi feita com o site
        if (str(browser.page.status_code)[0] != "2"):
            
            #Pegando as divs que contém as informações das empresas
            div = browser.page.find_all('div',class_='max-w-4xl mx-auto bg-white shadow overflow-hidden sm:rounded-md')
            for divList in div:
                
                #Acessando a lista de empresas para capturar o link e acessar os dados.
                ul = divList.find('ul',class_='divide-y divide-gray-200')
                for li in ul:
                    
                    #Validando se a lista contém item ou não de empresas
                    if li != ' ':
                        ancoras = li.find_all('a')
                        
                        #Captura o link que contém todos os dados da empresa
                        for ancora in ancoras:
                            link = ancora['href']
                            
                            #Acessando o link de dados da empresa se retornar erro finaliza a requisição e vai para próxima
                            infoEmpresa = requests.get(link)
                            if (str(infoEmpresa.status_code)[0] != "2"):
                                break
                            
                            #Acesso os dados da empresa
                            soupInfo = BeautifulSoup(infoEmpresa.content,"html.parser")
                            paragrafos = soupInfo.find_all('p')
                            
                            #Percorrendo as linhas para pegar os dados
                            for p in paragrafos:
                                findCaracter = int(str(p.text).find(":"))
                                item = str(p.text)[0:findCaracter]
                                
                                for campo in campos:        
                                    if campo == item:                                
                                        tamanho = int(len(p.text))
                                        findCaracter = int(findCaracter) + 1
                                        
                                        #Salvando dado no dataset no dataset
                                        columns = campos[campo]
                                        dfCnpj.loc[row] = [empresaPrincipal,columns,str(p.text)[findCaracter:tamanho]]
                                        row = row + 1
                                        break
   
    #Inner join com os dado coletados no site
    if len(dfCnpj) > 1:
        dfCnpjVagas = pd.merge(df,dfCnpj,on='Empresa')
        dfCnpjVagas.to_csv('R:\\Estrategia_Inovacao\\09 - Dados\\Python\\WebScraping_Vagas\\EmpresasComDados.csv')
        return dfCnpjVagas
    else:
        return None

def EnvioEmail(destino,assunto,body):
    #Iniciando o servidor de email
    s = smtp.SMTP(host='smtp.office365.com',port=587)
    s.starttls()
    s.login('', '')
    
    #Criando email e disparando
    msg = MIMEMultipart()
    msg['From'] = ''
    msg['To'] = destino
    msg['Subject'] = assunto
    msg.attach(MIMEText(body))
    s.send_message(msg)

def TimeExecucao(Tempo):
    #Contador de tempo de execução, utilizado para aguardar o tempo de execução de um processo, evitando erro no código
    contador = 0
    while (contador<= Tempo):
        contador = contador + 1

#Método main que inicia a execução do código    
if __name__ == '__main__':
    dfFinal = wsCnpjEmpresas(dfVagas)